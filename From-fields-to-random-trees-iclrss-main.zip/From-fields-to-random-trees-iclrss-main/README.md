# From-fields-to-random-trees-iclr
This is the code of the paper From Fields to Random Trees for the ICLR 2026.

You need to modify the content of cmakelists.txt and other paths that with "YOUR_PATH_TO" with the actual path in your enviorment.

Then you can run the program through the main.cpp. 

The file you use should be in .uai format.
